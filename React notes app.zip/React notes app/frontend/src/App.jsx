import './App.css'
import './register.jsx'
import loginImg from './download__2_-removebg-preview.png' // Make sure the image is inside src folder or adjust the path accordingly

function App() {
  return (
    <div className="login-bg">
      <div className="login-card">
        <div className="login-left">
          <h2 className="login-title">Log In</h2>
          <form>
            <label>Email</label>
            <input type="email" placeholder="Your Email" />
            <label>Password</label>
            <input type="password" placeholder="Your Password" />
            <button type="submit" className="login-btn">Login</button>
          </form>
          <p className="register-link">
            Do you have an account? <span> Register </span>
          </p>
        </div>
        <div className="login-right">
          <img src={loginImg} alt="Login Illustration" />
        </div>
      </div>
    </div>
  )
}

export default App